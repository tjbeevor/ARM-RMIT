import type { Express } from "express";
import { createServer } from "http";
import multer from "multer";
import { db } from "@db";
import { assessmentCriteria, assessments, chatHistory } from "@db/schema";
import { eq } from "drizzle-orm";
import { analyzeCriteriaDocument, analyzeAssignment, chatWithContext } from "./services/gemini";
import PDFParser from "pdf-parse/lib/pdf-parse.js";

const upload = multer();

export function registerRoutes(app: Express) {
  const httpServer = createServer(app);

  app.post("/api/upload", upload.single("document"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const type = req.body.type as "criteria" | "assignment";
      if (!type) {
        return res.status(400).json({ message: "Upload type not specified" });
      }

      let content: string;

      // Handle different file types
      if (req.file.mimetype === "application/pdf") {
        try {
          const pdfData = await PDFParser(req.file.buffer);
          content = pdfData.text;
        } catch (pdfError) {
          console.error("PDF parsing error:", pdfError);
          return res.status(400).json({ message: "Failed to parse PDF file" });
        }
      } else if (req.file.mimetype === "text/plain" || req.file.mimetype === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
        content = req.file.buffer.toString("utf-8");
      } else {
        return res.status(400).json({ message: "Unsupported file type" });
      }

      content = content
        .replace(/\r\n/g, "\n")
        .replace(/\s+/g, " ")
        .trim();

      console.log(`Processing ${type} document with content length:`, content.length);

      if (type === "criteria") {
        // For criteria uploads, analyze and create assessment framework
        const analysis = await analyzeCriteriaDocument(content);
        console.log("Generated assessment framework");

        const [criteria] = await db
          .insert(assessmentCriteria)
          .values({
            name: "Assessment Criteria",
            criteria: analysis,
          })
          .returning();

        return res.json({ id: criteria.id, content: analysis });
      } else {
        // Get metadata from request body
        const { title, assessorName, studentName } = req.body;

        if (!title || !assessorName || !studentName) {
          return res.status(400).json({ message: "Missing required metadata fields" });
        }

        // For assignment uploads, store content and metadata
        const [document] = await db
          .insert(assessments)
          .values({
            documentContent: content,
            title,
            assessorName,
            studentName,
          })
          .returning();

        return res.json({ id: document.id, content });
      }
    } catch (error) {
      console.error("Upload error:", error);
      res.status(500).json({ message: "Upload failed: " + (error instanceof Error ? error.message : "Unknown error") });
    }
  });

  app.post("/api/criteria", async (req, res) => {
    try {
      const { content } = req.body;
      const [criteria] = await db
        .insert(assessmentCriteria)
        .values({
          name: "Assessment Criteria",
          criteria: content,
        })
        .returning();

      res.json(criteria);
    } catch (error) {
      console.error("Save criteria error:", error);
      res.status(500).json({ message: "Failed to save criteria" });
    }
  });

  app.post("/api/assess", async (req, res) => {
    try {
      const { documentId, criteriaId } = req.body;
      console.log(`Assessing document ${documentId} with criteria ${criteriaId}`);

      // Get the assessment criteria
      const criteria = await db.query.assessmentCriteria.findFirst({
        where: eq(assessmentCriteria.id, criteriaId),
      });

      if (!criteria) {
        console.log("Assessment criteria not found");
        return res.status(404).json({ message: "Assessment criteria not found" });
      }

      // Get the document content and metadata
      const document = await db.query.assessments.findFirst({
        where: eq(assessments.id, documentId),
      });

      if (!document) {
        console.log("Document not found");
        return res.status(404).json({ message: "Document not found" });
      }

      console.log("Starting assessment analysis...");
      const assessment = await analyzeAssignment(
        document.documentContent,
        criteria.criteria as string
      );
      console.log("Assessment analysis completed");

      if (!assessment) {
        throw new Error("Failed to generate assessment");
      }

      // Format the assessment with metadata
      const timestamp = new Date().toLocaleString();
      const formattedAssessment = `# Assessment Report

## Metadata
- **Assessment Title:** ${document.title}
- **Assessor:** ${document.assessorName}
- **Student:** ${document.studentName}
- **Date:** ${timestamp}

${assessment}`;

      // Update the assessment with the results and criteriaId
      const [result] = await db
        .update(assessments)
        .set({
          result: formattedAssessment,
          criteriaId: criteria.id,
        })
        .where(eq(assessments.id, documentId))
        .returning();

      console.log("Assessment results saved to database");

      res.json({
        id: result.id,
        assessment: formattedAssessment,
      });
    } catch (error) {
      console.error("Assessment error:", error);
      res.status(500).json({ 
        message: "Assessment failed: " + (error instanceof Error ? error.message : "Unknown error") 
      });
    }
  });

  app.post("/api/chat", async (req, res) => {
    try {
      const { assessmentId, message } = req.body;

      const assessment = await db.query.assessments.findFirst({
        where: eq(assessments.id, assessmentId),
        with: {
          criteria: true,
        },
      });

      if (!assessment) {
        return res.status(404).json({ message: "Assessment not found" });
      }

      const response = await chatWithContext(
        message,
        assessment.documentContent,
        assessment.criteria.criteria as string,
        assessment.result as string
      );

      await db.insert(chatHistory).values({
        assessmentId,
        messages: [
          { role: "user", content: message },
          { role: "assistant", content: response },
        ],
      });

      res.json({ message: response });
    } catch (error) {
      console.error("Chat error:", error);
      res.status(500).json({ message: "Chat failed" });
    }
  });

  return httpServer;
}