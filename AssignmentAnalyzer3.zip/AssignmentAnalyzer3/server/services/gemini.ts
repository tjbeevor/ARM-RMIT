import { GoogleGenerativeAI } from "@google/generative-ai";

if (!process.env.GEMINI_API_KEY) {
  throw new Error("GEMINI_API_KEY environment variable is required");
}

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

const CRITERIA_ANALYSIS_PROMPT = `Please analyze this assignment document and extract a comprehensive assessment framework by:
Identifying all core evaluation criteria components including:
Each main criterion/category
The weight or percentage allocated (if specified)
The specific elements being assessed within each criterion
The performance levels or expectations described
Noting any specific requirements for:
Format and structure
Word count or length restrictions
Reference/citation requirements
Required elements or sections
Submission guidelines
Extracting any key assessment features like:
Learning outcomes being assessed
Required source types or quantities
Specific models or frameworks that must be applied
Any tools or concepts that must be demonstrated
Identifying the grading bands/levels (e.g., HD, DI, C, P, F) and their:
Score ranges
Descriptive criteria for each level
Key differentiators between levels
Please organize this information into a clear framework that could be used to evaluate submissions consistently.

Document to analyze:
`;

export async function analyzeCriteriaDocument(content: string): Promise<string> {
  try {
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });
    const result = await model.generateContent(CRITERIA_ANALYSIS_PROMPT + content);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error("Gemini API error:", error);
    throw new Error("Failed to analyze document with Gemini");
  }
}

export async function analyzeAssignment(
  assignment: string,
  criteria: string
): Promise<string> {
  try {
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });
    const prompt = `Using the following assessment criteria:
${criteria}

Please evaluate this assignment:
${assignment}

Provide a detailed assessment including:
1. Score or grade for each criterion
2. Justification for each score
3. Specific examples from the assignment
4. Areas for improvement
5. Overall grade and summary`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error("Gemini API error:", error);
    throw new Error("Failed to analyze assignment with Gemini");
  }
}

export async function chatWithContext(
  message: string,
  assignment: string,
  criteria: string,
  assessment: string
): Promise<string> {
  try {
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });
    const prompt = `Context:
Assessment Criteria: ${criteria}
Assignment: ${assignment}
Current Assessment: ${assessment}

Question: ${message}

Please provide a detailed response considering the assessment context.`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error("Gemini API error:", error);
    throw new Error("Failed to generate chat response with Gemini");
  }
}
