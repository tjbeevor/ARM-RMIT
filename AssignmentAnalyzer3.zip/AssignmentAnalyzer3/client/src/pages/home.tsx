import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DocumentUploader } from "@/components/document-uploader";
import { AssessmentEditor } from "@/components/assessment-editor";
import { ChatModal } from "@/components/chat-modal";
import { useToast } from "@/hooks/use-toast";
import { useAssessDocument } from "@/lib/api";
import { ChevronDown, ChevronUp, Copy, Check } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

// Import the banner image directly
import bannerImg from "/banner.jpg";

export default function Home() {
  const [criteriaContent, setCriteriaContent] = useState<string>("");
  const [showEditor, setShowEditor] = useState(false);
  const [assessmentId, setAssessmentId] = useState<number | null>(null);
  const [assessmentResult, setAssessmentResult] = useState<string>("");
  const [isCriteriaSaved, setIsCriteriaSaved] = useState(false);
  const [isEditorCollapsed, setIsEditorCollapsed] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const { toast } = useToast();
  const assessMutation = useAssessDocument();

  const handleCriteriaUpload = (id: number, content: string) => {
    try {
      console.log("Received criteria content:", content);
      setCriteriaContent(content);
      setShowEditor(true);
      toast({
        title: "Criteria uploaded",
        description: "You can now edit the generated assessment framework.",
      });
    } catch (error) {
      console.error("Error handling criteria upload:", error);
      toast({
        title: "Error",
        description: "Failed to process assessment criteria.",
        variant: "destructive",
      });
    }
  };

  const handleAssignmentUpload = async (documentId: number) => {
    try {
      const result = await assessMutation.mutateAsync({
        documentId,
        criteriaId: 1, // assuming we're using the latest criteria
      });

      if (!result.assessment) {
        throw new Error("No assessment result returned");
      }

      setAssessmentId(result.id);
      setAssessmentResult(result.assessment);

      toast({
        title: "Assessment complete",
        description: "The assignment has been assessed according to the criteria.",
      });
    } catch (error) {
      console.error("Assessment error:", error);
      toast({
        title: "Assessment failed",
        description: "There was an error assessing the assignment.",
        variant: "destructive",
      });
    }
  };

  const handleCopyAssessment = async () => {
    try {
      await navigator.clipboard.writeText(assessmentResult);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
      toast({
        title: "Copied",
        description: "Assessment result copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Copy failed",
        description: "Failed to copy assessment result",
        variant: "destructive",
      });
    }
  };

  const handleSaveCriteria = async (content: string) => {
    try {
      const response = await fetch("/api/criteria", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
      });

      if (response.ok) {
        toast({
          title: "Criteria saved",
          description: "Your assessment framework has been saved successfully.",
        });
        setIsCriteriaSaved(true);
        setIsEditorCollapsed(true);
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save assessment criteria.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <div className="flex justify-center py-8 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <img 
              src={bannerImg} 
              alt="AI Assignment Assessment Platform Banner" 
              className="w-full h-auto object-contain"
            />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 flex-1">
        <div className="max-w-4xl mx-auto space-y-8">
          {!showEditor ? (
            <Card className="bg-white border border-[#290D40]/10 shadow-lg">
              <CardHeader>
                <CardTitle>Upload assessment criteria</CardTitle>
              </CardHeader>
              <CardContent>
                <DocumentUploader
                  type="criteria"
                  onUploadComplete={handleCriteriaUpload}
                />
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              <Card className="bg-white border border-[#290D40]/10 shadow-lg">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle>Assessment framework</CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsEditorCollapsed(!isEditorCollapsed)}
                    className="text-[#00D5FF] hover:text-[#FF0178]"
                  >
                    {isEditorCollapsed ? <ChevronDown className="h-4 w-4" /> : <ChevronUp className="h-4 w-4" />}
                  </Button>
                </CardHeader>
                {!isEditorCollapsed && (
                  <CardContent>
                    <AssessmentEditor
                      initialContent={criteriaContent}
                      onSave={handleSaveCriteria}
                    />
                  </CardContent>
                )}
              </Card>
            </div>
          )}

          <div className={`space-y-8 transition-opacity duration-200 ${!isCriteriaSaved ? 'opacity-50 pointer-events-none' : ''}`}>
            <Card className="bg-white border border-[#290D40]/10 shadow-lg">
              <CardHeader>
                <CardTitle>Upload assignment</CardTitle>
              </CardHeader>
              <CardContent>
                {assessMutation.isPending ? (
                  <div className="flex flex-col items-center py-8">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#FF0178] mb-4" />
                    <p className="text-sm text-[#290D40]">Processing assessment...</p>
                  </div>
                ) : (
                  <DocumentUploader
                    type="assignment"
                    onUploadComplete={handleAssignmentUpload}
                  />
                )}
              </CardContent>
            </Card>

            {assessmentResult && (
              <Card className="bg-white border border-[#290D40]/10 shadow-lg">
                <CardHeader className="flex flex-row items-center justify-between space-y-0">
                  <CardTitle>Assessment Result</CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleCopyAssessment}
                    className="gap-2 text-[#00D5FF] hover:text-[#FF0178]"
                  >
                    {isCopied ? (
                      <>
                        <Check className="h-4 w-4" />
                        Copied
                      </>
                    ) : (
                      <>
                        <Copy className="h-4 w-4" />
                        Copy
                      </>
                    )}
                  </Button>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="raw">
                    <TabsList className="mb-4">
                      <TabsTrigger value="raw">Raw Markdown</TabsTrigger>
                      <TabsTrigger value="formatted">Formatted</TabsTrigger>
                    </TabsList>
                    <TabsContent value="raw">
                      <pre className="whitespace-pre-wrap font-mono text-sm bg-[#290D40]/5 p-4 rounded-md">
                        {assessmentResult}
                      </pre>
                    </TabsContent>
                    <TabsContent value="formatted" className="prose prose-sm max-w-none dark:prose-invert">
                      <ReactMarkdown remarkPlugins={[remarkGfm]}>
                        {assessmentResult}
                      </ReactMarkdown>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        <ChatModal assessmentId={assessmentId} />
      </div>

      <footer className="py-8 mt-12">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <p className="text-sm text-muted-foreground">SEI AI prototype</p>
          </div>
        </div>
      </footer>
    </div>
  );
}