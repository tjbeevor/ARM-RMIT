import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { DocumentUploader } from "@/components/document-uploader";
import { ChatInterface } from "@/components/chat-interface";
import { useToast } from "@/hooks/use-toast";
import { useAssessDocument } from "@/lib/api";
import { ChatModal } from "@/components/chat-modal";

export default function Assessment() {
  const [assessmentId, setAssessmentId] = useState<number | null>(null);
  const [assessmentResult, setAssessmentResult] = useState<string>("");
  const { toast } = useToast();
  const assessMutation = useAssessDocument();

  const handleAssignmentUpload = async (documentId: number) => {
    try {
      const result = await assessMutation.mutateAsync({
        documentId,
        criteriaId: 1, // assuming we're using the latest criteria
      });

      setAssessmentId(result.id);
      setAssessmentResult(result.assessment);

      toast({
        title: "Assessment complete",
        description: "The assignment has been assessed according to the criteria.",
      });
    } catch (error) {
      toast({
        title: "Assessment failed",
        description: "There was an error assessing the assignment.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-4xl font-bold mb-8 text-center">
        Assignment Assessment
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Upload Assignment</CardTitle>
            </CardHeader>
            <CardContent>
              <DocumentUploader
                type="assignment"
                onUploadComplete={(id) => handleAssignmentUpload(id)}
              />
            </CardContent>
          </Card>

          {assessmentResult && (
            <Card>
              <CardHeader>
                <CardTitle>Assessment Result</CardTitle>
              </CardHeader>
              <CardContent>
                <pre className="whitespace-pre-wrap font-mono text-sm">
                  {assessmentResult}
                </pre>
              </CardContent>
            </Card>
          )}
        </div>

        {assessmentId && (
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Ask Questions About This Assignment</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Get help understanding the student's work in context with the assessment criteria.
                  Ask questions about specific aspects of the assignment or how it meets the requirements.
                </p>
                <ChatInterface assessmentId={assessmentId} />
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      {/* Add the floating chat button for mobile view */}
      <ChatModal assessmentId={assessmentId} />
    </div>
  );
}