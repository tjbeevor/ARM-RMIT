import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { MessageCircle } from "lucide-react";
import { ChatInterface } from "./chat-interface";

interface ChatModalProps {
  assessmentId: number | null;
}

export function ChatModal({ assessmentId }: ChatModalProps) {
  const [isOpen, setIsOpen] = useState(false);

  if (!assessmentId) return null;

  return (
    <>
      <Button
        className="fixed bottom-4 right-4 rounded-full w-12 h-12 p-0"
        onClick={() => setIsOpen(true)}
      >
        <MessageCircle className="h-6 w-6" />
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-[800px] h-[80vh]">
          <DialogHeader>
            <DialogTitle>Assessment Chat</DialogTitle>
          </DialogHeader>
          <div className="flex-1 overflow-hidden">
            <ChatInterface assessmentId={assessmentId} />
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
