import { Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { useUploadDocument } from "@/lib/api";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

const uploadSchema = z.object({
  title: z.string().min(1, "Title is required"),
  assessorName: z.string().min(1, "Assessor name is required"),
  studentName: z.string().min(1, "Student name is required"),
});

type UploadFormData = z.infer<typeof uploadSchema>;

interface DocumentUploaderProps {
  onUploadComplete: (id: number, content: string) => void;
  type: "criteria" | "assignment";
}

export function DocumentUploader({ onUploadComplete, type }: DocumentUploaderProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const { toast } = useToast();
  const uploadMutation = useUploadDocument();

  const form = useForm<UploadFormData>({
    resolver: zodResolver(uploadSchema),
    defaultValues: {
      title: "",
      assessorName: "",
      studentName: "",
    },
  });

  const handleUpload = async (formData: UploadFormData) => {
    if (!selectedFile) {
      toast({
        title: "No file selected",
        description: "Please select a file to upload",
        variant: "destructive",
      });
      return;
    }

    try {
      const result = await uploadMutation.mutateAsync({
        file: selectedFile,
        type,
        title: formData.title,
        assessorName: formData.assessorName,
        studentName: formData.studentName,
      });

      onUploadComplete(result.id, result.content);
      setSelectedFile(null);
      form.reset();

      toast({
        title: "Upload successful",
        description: `${type === 'criteria' ? 'Assessment criteria' : 'Assignment'} uploaded successfully.`,
      });
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "There was an error uploading your document.",
        variant: "destructive",
      });
    }
  };

  const handleCriteriaUpload = async (file: File) => {
    try {
      const result = await uploadMutation.mutateAsync({
        file,
        type: "criteria",
      });
      onUploadComplete(result.id, result.content);
      toast({
        title: "Upload successful",
        description: "Assessment criteria uploaded successfully.",
      });
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "There was an error uploading your document.",
        variant: "destructive",
      });
    }
  };

  const handleFileSelect = async (file: File) => {
    if (type === "criteria") {
      await handleCriteriaUpload(file);
    } else {
      setSelectedFile(file);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleUpload)} className="space-y-4">
        {type === "assignment" && (
          <div className="space-y-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Assessment Title</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter assessment title" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="assessorName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Assessor Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter assessor name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="studentName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Student Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter student name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        )}

        <Card
          className={`border-2 border-dashed ${
            isDragging ? "border-primary" : "border-gray-300"
          } rounded-lg ${uploadMutation.isPending ? "opacity-50" : ""}`}
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setIsDragging(false);
            const file = e.dataTransfer.files[0];
            if (file) handleFileSelect(file);
          }}
        >
          <CardContent className="p-6 text-center">
            {uploadMutation.isPending ? (
              <div className="flex flex-col items-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mb-4" />
                <p className="text-sm text-gray-500">Processing document...</p>
              </div>
            ) : (
              <>
                <Upload className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">
                  Upload {type === 'criteria' ? 'assessment criteria' : 'assignment'}
                </h3>
                <p className="mt-1 text-sm text-gray-500">
                  {selectedFile ? selectedFile.name : "Drag and drop your file here, or click to select"}
                </p>
                <Button
                  type="button"
                  variant="outline"
                  className="mt-4"
                  onClick={() => {
                    const input = document.createElement("input");
                    input.type = "file";
                    input.accept = ".doc,.docx,.pdf,.txt";
                    input.onchange = (e) => {
                      const file = (e.target as HTMLInputElement).files?.[0];
                      if (file) handleFileSelect(file);
                    };
                    input.click();
                  }}
                  disabled={uploadMutation.isPending}
                >
                  Select file
                </Button>
              </>
            )}
          </CardContent>
        </Card>

        {selectedFile && type === "assignment" && (
          <div className="flex justify-end">
            <Button type="submit" disabled={uploadMutation.isPending}>
              Upload Assessment
            </Button>
          </div>
        )}
      </form>
    </Form>
  );
}