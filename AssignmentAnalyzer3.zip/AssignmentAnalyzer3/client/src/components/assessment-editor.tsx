import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface AssessmentEditorProps {
  initialContent: string;
  onSave: (content: string) => void;
}

export function AssessmentEditor({ initialContent, onSave }: AssessmentEditorProps) {
  const [content, setContent] = useState(initialContent);
  const { toast } = useToast();

  const handleSave = () => {
    onSave(content);
    toast({
      title: "Changes saved",
      description: "Your assessment criteria have been updated.",
    });
  };

  return (
    <Card className="p-4">
      <Tabs defaultValue="edit">
        <TabsList className="mb-4">
          <TabsTrigger value="edit">Edit</TabsTrigger>
          <TabsTrigger value="preview">Preview</TabsTrigger>
        </TabsList>
        <TabsContent value="edit">
          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="min-h-[600px] mb-4 font-mono text-sm p-4"
            style={{
              whiteSpace: 'pre-wrap',
              fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace',
              lineHeight: '1.5',
            }}
          />
        </TabsContent>
        <TabsContent value="preview" className="prose prose-sm max-w-none dark:prose-invert">
          <ReactMarkdown 
            remarkPlugins={[remarkGfm]}
            className="p-4"
          >
            {content}
          </ReactMarkdown>
        </TabsContent>
      </Tabs>
      <div className="flex justify-end">
        <Button onClick={handleSave}>Save Changes</Button>
      </div>
    </Card>
  );
}