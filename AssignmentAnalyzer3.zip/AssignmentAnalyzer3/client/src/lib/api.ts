import { useMutation, useQuery } from "@tanstack/react-query";
import { queryClient } from "./queryClient";

interface UploadResponse {
  id: number;
  content: string;
}

interface UploadParams {
  file: File;
  type: 'criteria' | 'assignment';
  title?: string;
  assessorName?: string;
  studentName?: string;
}

export const useUploadDocument = () => {
  return useMutation({
    mutationFn: async ({ file, type, title, assessorName, studentName }: UploadParams) => {
      const formData = new FormData();
      formData.append("document", file);
      formData.append("type", type);

      if (type === 'assignment') {
        if (!title || !assessorName || !studentName) {
          throw new Error("Missing required metadata for assignment upload");
        }
        formData.append("title", title);
        formData.append("assessorName", assessorName);
        formData.append("studentName", studentName);
      }

      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(error);
      }

      return response.json() as Promise<UploadResponse>;
    },
  });
};

export const useAssessDocument = () => {
  return useMutation({
    mutationFn: async ({ documentId, criteriaId }: { documentId: number; criteriaId: number }) => {
      const response = await fetch("/api/assess", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ documentId, criteriaId }),
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(error);
      }

      return response.json();
    },
  });
};

export const useChatMessage = () => {
  return useMutation({
    mutationFn: async ({ assessmentId, message }: { assessmentId: number; message: string }) => {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ assessmentId, message }),
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(error);
      }

      return response.json();
    },
  });
};

export const useGetAssessments = () => {
  return useQuery({
    queryKey: ["/api/assessments"],
  });
};

export const useGetCriteria = () => {
  return useQuery({
    queryKey: ["/api/criteria"],
  });
};