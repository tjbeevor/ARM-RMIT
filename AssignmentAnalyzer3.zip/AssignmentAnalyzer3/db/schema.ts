import { pgTable, text, serial, timestamp, jsonb, integer } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";

export const assessmentCriteria = pgTable("assessment_criteria", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  criteria: jsonb("criteria").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

export const assessments = pgTable("assessments", {
  id: serial("id").primaryKey(),
  criteriaId: integer("criteria_id").references(() => assessmentCriteria.id),  
  title: text("title"),  
  assessorName: text("assessor_name"),  
  studentName: text("student_name"),  
  documentContent: text("document_content").notNull(),
  result: jsonb("result"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

export const chatHistory = pgTable("chat_history", {
  id: serial("id").primaryKey(),
  assessmentId: serial("assessment_id").references(() => assessments.id),
  messages: jsonb("messages").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Define relations
export const assessmentRelations = relations(assessments, ({ one }) => ({
  criteria: one(assessmentCriteria, {
    fields: [assessments.criteriaId],
    references: [assessmentCriteria.id],
  }),
}));

export type Assessment = typeof assessments.$inferSelect;
export type AssessmentCriteria = typeof assessmentCriteria.$inferSelect;
export type ChatHistory = typeof chatHistory.$inferSelect;